package com.example.city.data

import com.example.city.R
import com.example.city.model.Recommendation

object LocalRecommendationDataProvider {
    val recommendations: List<Recommendation> = listOf(
        Recommendation(
            id = 1,
            n = R.string.coffee_1,
            type = R.string.i_1,
            add = R.string.coffee_add_1,
            definition = R.string.coffee_definition_1,
            image = R.drawable.cafe1
        ),

        Recommendation(
            id = 2,
            n = R.string.coffee_2,
            type = R.string.i_1,
            add = R.string.coffee_add_2,
            definition = R.string.coffee_definition_2,
            image = R.drawable.cafe2
        ),

        Recommendation(
            id = 3,
            n = R.string.coffee_3,
            type = R.string.i_1,
            add = R.string.coffee_add_3,
            definition = R.string.coffee_definition_3,
            image = R.drawable.cafe3
        ),
        Recommendation(
            id = 4,
            n = R.string.rest_1,
            type = R.string.i_2,
            add = R.string.rest_add_1,
            definition = R.string.restaurant_definition_1,
            image = R.drawable.res1
        ),
        Recommendation(
            id = 5,
            n = R.string.rest_2,
            type = R.string.i_2,
            add = R.string.rest_add_2,
            definition = R.string.restaurant_definition_2,
            image = R.drawable.res2
        ),
        Recommendation(
            id = 6,
            n = R.string.rest_3,
            type = R.string.i_2,
            add = R.string.rest_add_3,
            definition = R.string.restaurant_definition_3,
            image = R.drawable.res3
        ),
        Recommendation(
            id = 7,
            n = R.string.k_1,
            type = R.string.i_3,
            add = R.string.k_add_1,
            definition = R.string.k_definition_1,
            image = R.drawable.child1
        ),
        Recommendation(
            id = 8,
            n = R.string.k_2,
            type = R.string.i_3,
            add = R.string.k_add_2,
            definition = R.string.k_definition_2,
            image = R.drawable.child2
        ),
        Recommendation(
            id = 9,
            n = R.string.k_3,
            type = R.string.i_3,
            add = R.string.k_add_3,
            definition = R.string.k_definition_3,
            image = R.drawable.child3
        ),
        Recommendation(
            id = 10,
            n = R.string.p_1,
            type = R.string.i_4,
            add = R.string.p_add_1,
            definition = R.string.p_definition_1,
            image = R.drawable.park1
        ),
        Recommendation(
            id = 11,
            n = R.string.p_2,
            type = R.string.i_4,
            add = R.string.p_add_2,
            definition = R.string.p_definition_2,
            image = R.drawable.park2
        ),
        Recommendation(
            id = 12,
            n = R.string.p_3,
            type = R.string.i_4,
            add = R.string.p_add_3,
            definition = R.string.p_definition_3,
            image = R.drawable.park3
        ),
        Recommendation(
            id = 13,
            n = R.string.shop_1,
            type = R.string.i_5,
            add = R.string.shop_add_1,
            definition = R.string.shop_definition_1,
            image = R.drawable.shop1
        ),
        Recommendation(
            id = 14,
            n = R.string.shop_2,
            type = R.string.i_5,
            add = R.string.shop_add_2,
            definition = R.string.shop_definition_2,
            image = R.drawable.shop2
        ),
        Recommendation(
            id = 15,
            n = R.string.shop_3,
            type = R.string.i_5,
            add = R.string.shop_add_3,
            definition = R.string.shop_definition_3,
            image = R.drawable.shop3
        )
    )
}