package com.example.city.model

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

data class Recommendation(
    val id: Int,
    @StringRes val n: Int,
    @StringRes val type: Int,
    @StringRes val add: Int,
    @StringRes val definition: Int,
    @DrawableRes val image: Int,
)