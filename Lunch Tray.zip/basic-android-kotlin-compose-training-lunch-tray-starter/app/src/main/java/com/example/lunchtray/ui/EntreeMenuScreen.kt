
package com.example.lunchtray.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.tooling.preview.Preview
import com.example.lunchtray.R
import com.example.lunchtray.datasource.DataSource
import com.example.lunchtray.model.MenuItem
import com.example.lunchtray.model.MenuItem.EntreeItem

@Composable
fun EntreeScreen(
    opt: List<EntreeItem>,
    onCancel: () -> Unit,
    onNext: () -> Unit,
    onSelect: (EntreeItem) -> Unit,
    modifier: Modifier = Modifier
) {
    BaseMenu(
        opt = opt,
        onCancel = onCancel,
        onNext = onNext,
        onselect = onSelect as (MenuItem) -> Unit,
        modifier = modifier
    )
}

@Preview
@Composable
fun EntreePreview(){
    EntreeScreen(
        opt = DataSource.entreeMenuItems,
        onCancel = {},
        onNext = {},
        onSelect = {},
        modifier = Modifier
            .padding(dimensionResource(R.dimen.padding_medium))
            .verticalScroll(rememberScrollState())
    )
}
