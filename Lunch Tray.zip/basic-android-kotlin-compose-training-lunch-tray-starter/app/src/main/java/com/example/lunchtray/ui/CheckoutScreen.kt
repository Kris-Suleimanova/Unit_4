
package com.example.lunchtray.ui

import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Divider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import com.example.lunchtray.R
import com.example.lunchtray.datasource.DataSource
import com.example.lunchtray.model.MenuItem
import com.example.lunchtray.model.OrderUiState

@Composable
fun CheckScreen(
    order: OrderUiState,
    onNext: () -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(dimensionResource(R.dimen.padding_small))
    ) {
        Text(
            text = stringResource(R.string.order_summary),
            fontWeight = FontWeight.Bold
        )
        ISum(i = order.entree, modifier = Modifier.fillMaxWidth())
        ISum(i = order.accompaniment, modifier = Modifier.fillMaxWidth())
        ISum(i = order.sideDish, modifier = Modifier.fillMaxWidth())


        Divider(
            thickness = dimensionResource(R.dimen.thickness_divider),
            modifier = Modifier.padding(bottom = dimensionResource(R.dimen.padding_small))
        )

        Cost(
            resourceId = R.string.subtotal,
            price = order.itemTotalPrice.formP(),
            Modifier.align(Alignment.End)
        )

        Cost(
            resourceId = R.string.tax,
            price = order.orderTax.formP(),
            Modifier.align(Alignment.End)
        )

        Text(
            modifier = Modifier.align(Alignment.End),
            fontWeight = FontWeight.Bold,
            text = stringResource(R.string.total, order.orderTotalPrice.formP()),

        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(dimensionResource(R.dimen.padding_medium)),
            horizontalArrangement = Arrangement.spacedBy(dimensionResource(R.dimen.padding_medium))
        ){
            OutlinedButton(modifier = Modifier.weight(1f), onClick = onCancel) {
                Text(stringResource(R.string.cancel).uppercase())
            }
            Button(
                modifier = Modifier.weight(1f),
                onClick = onNext
            ) {
                Text(stringResource(R.string.submit).uppercase())
            }
        }
    }
}

@Composable
fun ISum(
    i: MenuItem?,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(i?.name ?: "")
        Text(i?.getFormattedPrice() ?: "")
    }
}

@Composable
fun Cost(
    @StringRes resourceId: Int,
    price: String,
    modifier: Modifier = Modifier
) {
    Text(
        text = stringResource(resourceId, price),
        modifier = modifier
    )
}

@Preview
@Composable
fun CheckoutPreview() {
    CheckScreen(
        order = OrderUiState(
            orderTax = 1.00,
            orderTotalPrice = 16.00,
            sideDish = DataSource.sideDishMenuItems[0],
            entree = DataSource.entreeMenuItems[0],
            accompaniment = DataSource.accompanimentMenuItems[0],
            itemTotalPrice = 15.00,


        ),
        onCancel = {},
        onNext = {},
        modifier = Modifier
            .padding(dimensionResource(R.dimen.padding_medium))
            .verticalScroll(rememberScrollState())
    )
}
