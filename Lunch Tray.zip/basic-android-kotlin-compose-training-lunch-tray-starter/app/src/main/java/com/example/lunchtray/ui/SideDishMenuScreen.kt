
package com.example.lunchtray.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.tooling.preview.Preview
import com.example.lunchtray.R
import com.example.lunchtray.datasource.DataSource
import com.example.lunchtray.model.MenuItem
import com.example.lunchtray.model.MenuItem.SideDishItem

@Composable
fun SideDishScreen(
    opt: List<SideDishItem>,
    onCancel: () -> Unit,
    onNext: () -> Unit,
    onSelect: (SideDishItem) -> Unit,
    modifier: Modifier = Modifier
) {
    BaseMenu(
        opt = opt,
        onCancel = onCancel,
        onNext = onNext,
        onselect = onSelect as (MenuItem) -> Unit,
        modifier = modifier
    )
}

@Preview
@Composable
fun SideDishPreview(){
    SideDishScreen(
        opt = DataSource.sideDishMenuItems,
        onNext = {},
        onCancel = {},
        onSelect = {},
        modifier = Modifier
            .padding(dimensionResource(R.dimen.padding_medium))
            .verticalScroll(rememberScrollState())
    )
}
