
package com.example.lunchtray.ui
import com.example.lunchtray.model.OrderUiState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.text.NumberFormat

import androidx.lifecycle.ViewModel
import com.example.lunchtray.model.MenuItem
import com.example.lunchtray.model.MenuItem.AccompanimentItem
import com.example.lunchtray.model.MenuItem.EntreeItem
import com.example.lunchtray.model.MenuItem.SideDishItem

class OrderViewModel : ViewModel() {

    private val taxRate = 0.08

    private val _uiState = MutableStateFlow(OrderUiState())
    val uiState: StateFlow<OrderUiState> = _uiState.asStateFlow()

    fun upSideDish(sideDish: SideDishItem) {
        val previousSideDish = _uiState.value.sideDish
        upItem(sideDish, previousSideDish)
    }


    fun upEntre(entree: EntreeItem) {
        val previousEntree = _uiState.value.entree
        upItem(entree, previousEntree)
    }

    fun rOrd() {
        _uiState.value = OrderUiState()
    }
    fun upAccompaniment(accompaniment: AccompanimentItem) {
        val previousAccompaniment = _uiState.value.accompaniment
        upItem(accompaniment, previousAccompaniment)
    }



    private fun upItem(newItem: MenuItem, previousItem: MenuItem?) {
        _uiState.update { currentState ->
            val previousItemPrice = previousItem?.price ?: 0.0

            val itemTotalPrice = currentState.itemTotalPrice - previousItemPrice + newItem.price

            val tax = itemTotalPrice * taxRate
            currentState.copy(
                itemTotalPrice = itemTotalPrice,

                orderTotalPrice = itemTotalPrice + tax,

                entree = if (newItem is EntreeItem) newItem else currentState.entree,

                sideDish = if (newItem is SideDishItem) newItem else currentState.sideDish,

                orderTax = tax,
                accompaniment =
                    if (newItem is AccompanimentItem) newItem else currentState.accompaniment
            )
        }
    }
}

fun Double.formP(): String {
    return NumberFormat.getCurrencyInstance().format(this)
}
