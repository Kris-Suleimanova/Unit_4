

package com.example.sports.utils


enum class SportsContentType {
    ListOnly, ListAndDetail
}
